^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package kinematics_exchanger
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2019-10-31)
------------------
* Changed: Renamed package swarm_kinematics_exchanger to kinematics_exchanger
* Contributors: Micha Sende

1.0.0 (2019-09-11)
------------------
* Initial release of swarm_kinematics_exchanger
* Contributors: Micha Sende
