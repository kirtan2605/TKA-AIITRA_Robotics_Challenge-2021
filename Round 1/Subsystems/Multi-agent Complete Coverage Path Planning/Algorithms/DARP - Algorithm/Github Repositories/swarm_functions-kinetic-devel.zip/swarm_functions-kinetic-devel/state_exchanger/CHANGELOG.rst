^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package state_exchanger
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2019-10-31)
------------------
* Initial release of state_exchanger
* Contributors: Micha Sende
