^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package area_division
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2019-10-31)
------------------
* Initial release of area_division
* Contributors: Micha Sende
