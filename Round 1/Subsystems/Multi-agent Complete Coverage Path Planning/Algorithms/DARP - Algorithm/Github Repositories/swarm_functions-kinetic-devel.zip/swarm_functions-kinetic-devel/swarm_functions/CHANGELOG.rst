^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package swarm_functions
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2019-10-31)
------------------
* Added: Package area_division
* Added: Package coverage_path
* Added: Package state_exchanger
* Added: Package target_monitor
* Changed: Renamed package swarm_kinematics_exchanger to kinematics_exchanger
* Fixed task_allocation: Use frame ID in messages
* Changed task_allocation: Use latched topics

1.0.0 (2019-09-11)
------------------
* Initial release
* Based on the SAR demo at the M18 review of the CPSwarm project
* Merged: Task assignment and compute cost into task allocation
* Changed: Swarm kinematics exchanger extends position exchanger.
