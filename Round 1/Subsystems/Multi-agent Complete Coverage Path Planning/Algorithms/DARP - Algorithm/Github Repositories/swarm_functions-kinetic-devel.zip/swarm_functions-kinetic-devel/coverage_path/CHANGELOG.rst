^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package coverage_path
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2019-10-31)
------------------
* Initial release of coverage_path
* Contributors: Micha Sende
