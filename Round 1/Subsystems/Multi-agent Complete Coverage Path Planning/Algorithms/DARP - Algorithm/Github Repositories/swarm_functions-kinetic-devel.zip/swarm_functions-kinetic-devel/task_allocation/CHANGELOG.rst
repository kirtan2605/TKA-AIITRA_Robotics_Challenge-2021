^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package task_allocation
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2019-10-31)
------------------
* Fixed: Use frame ID in messages
* Changed: Use latched topics
* Contributors: Micha Sende

1.0.0 (2019-09-11)
------------------
* Initial release of task_allocation
* Contributors: Micha Sende
