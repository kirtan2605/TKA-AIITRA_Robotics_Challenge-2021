^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
Changelog for package target_monitor
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

1.1.0 (2019-10-31)
------------------
* Initial release of target_monitor
* Contributors: Micha Sende
